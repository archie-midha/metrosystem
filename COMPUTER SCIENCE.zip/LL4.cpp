                        //program to demonstrate circular query operations
#include<iostream.h>
#include<conio.h>
#include<stdio.h>
class CIRQ
{
int queue[50];
int front,rear;
public:
CIRQ()
{
 front = rear=-1;
 }
void add(int val);
int del();
void display();
};
int n;
void main()
{ //int queue[30];
  //int front ,rear;
  int val;CIRQ c1;
  int choice;
  cout<<"\n enter the size of the queue";
  cin>>n;
 // front=rear=0;
  do
  { cout<<"\n***menu***";
    cout<<"\n 1.add ";
    cout<<"\n 2.delete";
    cout<<"\n 3.display";
    cout<<"\n enter your choice";
    cin>>choice;
    clrscr();
    switch(choice)
    { case 1:cout<<"\n enter the value to be added";
	    cin>>val;
	    c1.add(val);
	    break;
     case 2: val=c1.del();
	     cout<<"\n deleted value is"<<val;
	     break;
     case 3 :cout<<"\n the queue is";
	     c1.display();
	     break;
	 default: cout<<"\n wrong choice";
	 }
     }
     while(choice!=4);
  getch();
  }
 void CIRQ::add(int val)
 { if((rear+1)%n==front)
    cout<<"\n queue is full";
    else
    {rear=(rear+1)%n;
      queue[rear]=val;
      }
   }
int CIRQ::del()
{int v;
  if(front!=rear)
  { front=(front+1)%n;
    v=queue[front];
  }
  return v;
 }
 void CIRQ::display()
 { int i;
   i=front;
   while(i!=rear)
   { i=(i+1)%n;
   cout<<queue[i]<<" ";
   }
   }


