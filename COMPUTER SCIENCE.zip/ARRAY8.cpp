//Program to perform operations on Matrices    
#include<iostream.h>
#include<conio.h>
#include<process.h>                             //for exit()
#include<stdio.h>                               //for endl
class MATRIX
{ int a,b,c,d,e,f;
  int Mat1[100][100],Mat2[100][100];
  public:
  void Display();
  void Equality();
  void Add();
  void Subtract();
  void Prod();
  void Rowsum();
  void Colsum();
  void Diagsum();
  void Search();
};
 
void MATRIX::Display()                            //to enter and display
{ cout<<endl<<"\nYou chose (1): Enter and display"<<endl;
  cout<<"\nEnter number of Rows and Columns of Matrix 1:"<<endl;
  cin>>a>>b;
  cout<<"\nEnter number of Rows and Columns of Matrix 2:"<<endl;
  cin>>c>>d;
  cout<<"\nEnter Matrix 1\n";
  for(e=0;e<a;e++)
  { for(f=0;f<b;f++)
    cin>>Mat1[e][f];
  }
  cout<<"\nInput Matrix 2\n";
  for(e=0;e<c;e++)
  { for(f=0;f<d;f++)
    cin>>Mat2[e][f];
  }
  cout<<"The entered Matrices are:\n";
  for(e=0;e<a;e++)
  { cout<<"\n";
    for(f=0;f<b;f++)
    cout<<" "<<Mat1[e][f];
  }
  cout<<"\n";
  for(e=0;e<c;e++)
  { cout<<"\n";
    for(f=0;f<d;f++)
    cout<<" "<<Mat2[e][f];
  }
}
void MATRIX::Equality()           //To check for equality
{ cout<<"You chose (2): Check for Equality ";
  cout<<"\nEnter rows and columns for matrix 1:\n";
  cin>>a>>b;
  cout<<"\nEnter rows and columns for matrix 2:\n";
  cin>>c>>d;
  cout<<"\nEnter Matrix 1\n";
  for(e=0;e<a;e++)
  { for(f=0;f<b;f++)
    cin>>Mat1[e][f];
  }
  cout<<"\nEnter Matrix 2\n";
  for(e=0;e<c;e++)
  { for(f=0;f<d;f++)
    cin>>Mat2[e][f];
  }
  int flag=1;
  for(e=0;e<a&&c;e++)
  { for(f=0;f<b&&d;f++)
    { if(Mat1[e][f]!=Mat2[e][f])
       { flag=0;
	 break;
       }
    }
    if(flag==1)
    break;
  }
  if(flag==1)
  cout<<endl<<"Entered Matrices are Equal.";
  else
  cout<<endl<<"Entered Matrices are Unequal.";
}
void MATRIX::Add()                   //To add matrices
{ int Mat3[100][100];
  cout<<"You chose (3):Matrix addition";
  Start:
  cout<<"\nEnter rows and columns for matrix 1:\n";
  cin>>a>>b;
  cout<<"\nEnter rows and columns for matrix 2:\n";
  cin>>c>>d;
  if((a==c)&&(b==d))
    {cout<<"\nMatrices can be added";}
  else
    { cout<<"\n Matrices cant be added due to structural differences\n";
      goto Start;
    }
  cout<<"\nEnter Matrix 1:\n";
  for(e=0;e<a;e++)
  { for(f=0;f<b;f++)
    cin>>Mat1[e][f];
  }
  cout<<"\nEnter Matrix 2:\n";
  for(e=0;e<c;e++)
  { for(f=0;f<d;f++)
    cin>>Mat2[e][f];
  }
  cout<<"\nEntered Matrices are:\n";
  for(e=0;e<a;e++)
  { cout<<"\n";
    for(f=0;f<b;f++)
    cout<<" "<<Mat1[e][f];
  }
  cout<<"\n";
  for(e=0;e<c;e++)
  { cout<<"\n";
    for(f=0;f<d;f++)
    cout<<" "<<Mat2[e][f];
  }
  for(e=0;e<a&&c;e++)
  { for(f=0;f<b&&d;f++)
    Mat3[e][f]=Mat1[e][f]+Mat2[e][f];
  }
  cout<<"\nSum of Matrices:";
  for(e=0;e<a&&c;e++)
  { cout<<"\n";
    for(f=0;f<b&&d;f++)
    cout<<" "<<Mat3[e][f];
  }
}
void MATRIX::Subtract()                  //to subtract two matrices
{ int Mat3[100][100];
  cout<<"\nYou chose (4): Subtraction of matrices";
  Start:
  cout<<"\nEnter rows and columns for matrix 1:\n";
  cin>>a>>b;
  cout<<"\nEnter rows and columns for matrix 2:\n";
  cin>>c>>d;
  if((a==c)&&(b==d))
    cout<<"\nMatrices can be subtracted"<<endl;
  else
   { cout<<"\nMatrices cannot be subtracted. Input again."<<endl;
      goto Start;
   }
  cout<<"Enter Matrix 1:\n";
  for(e=0;e<a;e++)
  { for(f=0;f<b;f++)
    cin>>Mat1[e][f];
  }
  cout<<"\nEnter Matrix 2:\n";
  for(e=0;e<c;e++)
  { for(f=0;f<d;f++)
    cin>>Mat2[e][f];
  }
  cout<<"\nEntered Matrices are:\n";
  for(e=0;e<a;e++)
  { cout<<"\n";
    for(f=0;f<b;f++)
    cout<<" "<<Mat1[e][f];
  }
  cout<<"\n";
  for(e=0;e<c;e++)
  { cout<<"\n";
    for(f=0;f<d;f++)
    cout<<" "<<Mat2[e][f];
  }
  for(e=0;e<a&&c;e++)
  { for(f=0;f<b&&d;f++)
    Mat3[e][f]=Mat1[e][f]-Mat2[e][f];
  }
  cout<<"\nDifference of entered Matrices is:";
  for(e=0;e<a&&c;e++)
  { cout<<"\n";
    for(f=0;f<b&&d;f++)
    cout<<" "<<Mat3[e][f];
  }
}

void MATRIX::Prod()            //to multiply matrices
{ int Mat3[100][100];
  cout<<"\nYou chose (5)-Product of Matrices";
  cout<<"\nEnter rows and columns for matrix 1:\n";
  cin>>a>>b;
  cout<<"\nEnter rows and columns for matrix 2:\n";
  cin>>c>>d;
  cout<<"\nEnter Matrix 1:\n";
  for(e=0;e<a;e++)
  { for(f=0;f<b;f++)
    cin>>Mat1[e][f];
  }
  cout<<"\nEnter Matrix 2:\n";
  for(e=0;e<c;e++)
  { for(f=0;f<d;f++)
    cin>>Mat2[e][f];
  }
  cout<<"\nThe Entered Matrices are:\n";
  for(e=0;e<a;e++)
  { cout<<"\n";
    for(f=0;f<b;f++)
    cout<<" "<<Mat1[e][f];
  }
  cout<<"\n";
  for(e=0;e<c;e++)
  { cout<<"\n";
    for(f=0;f<d;f++)
    cout<<" "<<Mat2[e][f];
  }
  for(e=0;e<a&&c;e++)
  { for(f=0;f<b&&d;f++)
    { Mat3[e][f]=0;
      for(int k=0;k<b&&d;k++)
      Mat3[e][f]+=Mat1[e][k]*Mat2[k][f];
    }
  }
  cout<<"\nThe Product of entered Matrices is:";
  for(e=0;e<a&&c;e++)
  { cout<<"\n";
    for(f=0;f<b&&d;f++)
    cout<<" "<<Mat3[e][f];
  }
}

void MATRIX::Diagsum()       //sum of diagonal elements
{ int sum=0;
  cout<<"\nYou chose (6):Diagonal Sum:";
  cout<<"\nEnter no. of rows and columns of the matrix:\n";
  cin>>a>>b;
  cout<<"\nEnter matrix:\n";
  for(e=0;e<a;e++)
  { for(f=0;f<b;f++)
    cin>>Mat1[e][f];
  }
  cout<<"\nEntered Matrix:\n";
  for(e=0;e<a;e++)
  { cout<<"\n";
    for(f=0;f<b;f++)
    cout<<" "<<Mat1[e][f];
  }
  cout<<"\n";
  for(e=0;e<a;e++)
  { for(f=0;f<b;f++)
    if(e==f)
    sum+=Mat1[e][f];
  }
  cout<<"\nSum of diagonal elements="<<sum;
}

void MATRIX::Rowsum()                  //sum of row elements
{ int r[100];
  cout<<"You chose (7): Row Sum"<<endl;
  cout<<"\nEnter no. of rows and columns of the matrix:\n";
  cin>>a>>b;
  cout<<"\nEnter Matrix1:\n";
  for(e=0;e<a;e++)
  { for(f=0;f<b;f++)
    cin>>Mat1[e][f];
  }
  cout<<"\nEntered Matrix2:\n";
  for(e=0;e<a;e++)
  { cout<<"\n";
    for(f=0;f<b;f++)
    cout<<" "<<Mat1[e][f];
  }
  cout<<"\n";
  for(e=0;e<a;e++)
  { r[e]=0;
    for(f=0;f<b;f++)
    r[e]+=Mat1[e][f];
  }
  for(e=0;e<a;e++)
  cout<<"\nSum of row elements of"<<e+1<<"="<<r[e];
}

void MATRIX::Colsum()                    //sum of elements in each column
{ int c[100];
  cout<<"\nYou chose (8): Column Sum:";
  cout<<"\nEnter no. of rows and columns of the matrix:\n";
  cin>>a>>b;
  cout<<"\nEnter matrix:\n";
  for(e=0;e<a;e++)
  { for(f=0;f<b;f++)
    cin>>Mat1[e][f];
  }
  cout<<"\nEntered Matrix:\n";
  for(e=0;e<a;e++)
  { cout<<"\n";
    for(f=0;f<b;f++)
    cout<<" "<<Mat1[e][f];
  }
  cout<<"\n";
  for(f=0;f<b;f++)
  { c[f]=0;
    for(e=0;e<a;e++)
    c[f]+=Mat1[f][e];
  }
  for(e=0;e<b;e++)
  cout<<"\nSum of row elements of"<<e+1<<"="<<c[e];
}

void MATRIX::Search()                 //search for an element in a matrix
{ cout<<"\nYou chose (9): Search for an element:";
  cout<<"\nEnter no. of rows and columns of the matrix:\n";
  cin>>a>>b;
  cout<<"\nEnter matrix:\n";
  for(e=0;e<a;e++)
  { for(f=0;f<b;f++)
    cin>>Mat1[e][f];
  }
  cout<<"\nEntered Matrix:\n";
  for(e=0;e<a;e++)
  { cout<<"\n";
    for(f=0;f<b;f++)
    cout<<" "<<Mat1[e][f];
  }
  int elem;
  Search:
  cout<<"\nEnter the digit to be Searched for:";
  cin>>elem;
  int flag=0;
  for(e=0;e<a;e++)
  { for(f=0;f<b;f++)
    {if(Mat1[e][f]==elem)
       flag=1;break;
    }
  }
  if(flag==1)
    cout<<"\nElement found at row:"<<e<<" "<<"column:"<<f;
  else
    cout<<"\nElement not present in the matrix";
  char ch;
  cout<<"\ndo you wish to re enter?(y/n)\n";
  cin>>ch;
  if(( ch=='y')||(ch=='Y'))
    goto Search;
}
void main()                             //Main body.
{ clrscr();
  MATRIX A;                             //Object �m� of type MATIX
  char ch='y';
  do { clrscr();
       cout<<"Welcome to the operator\n";
       cout<<"The Operation menu includes:"            //User Menu
	   <<"\n(1)Enter and Display"<<"\n"
	   <<"(2)Check for equality"<<"\n"
	   <<"(3)Add two matrices"<<"\n"
	   <<"(4)Subtract two matrices"<<"\n"
	   <<"(5)Multiply two matrices"<<"\n"
	   <<"(6)Sum of Diagonal elements"<<"\n"
	   <<"(7)Sum of row elements"<<"\n"
	   <<"(8)Sum of column elements"<<"\n"
	   <<"(9) Search for an entered element" <<"\n"
	   <<"(@)Exit"<<endl;
  cout<<"Enter your choice:"<<endl;
  cin>>ch;
  switch(ch)                    // switch case for menu choice
      { case '1':A.Display();      break;
	case '2':A.Equality();    break;
	case '3':A.Add();           break;
	case '4':A.Subtract();    break;
	case '5':A.Prod();          break;
	case '6':A.Diagsum();   break;
	case '7':A.Rowsum();    break;
	case '8':A.Colsum();      break;
	case '9':A.Search();        break;
	case '$':cout<<"over";
		 exit(0);
	default :cout<<"Wrong Choice Entered:\n";    break;
       }
      cout<<"\n Do you wish to return back to the Main Menu? (y/n)\n";
      cin>>ch;
      }while((ch=='y')||(ch=='Y'));   // to return back to the menu
getch();
}




 
 
 
 
 
 
 
 
 
 




