#include<fstream.h>  //for data file handling
#include<conio.h>
#include<stdio.h>
#include<process.h>   //for exit
#include<ctype.h>    //for "isalpha" type functions

char str[51];

void enter()
{fstream f1;
f1.open("ARCHIE.txt",ios::in|ios::out);
  if(!f1)
    {cout<<"\nNo file found";
     exit(-1);}
cout<<"\nEnter a string (max.50 characters)\n";
gets(str);
f1<<str;
f1.close();
}

void display()     //#1
{
fstream f1;
f1.open("ARCHIE.txt",ios::in|ios::app);
if(!f1)
    {cout<<"\nNo file found!!Exitting!!";
     exit(-1);}
cout<<"\nThe entered string is:\n";
f1.getline(str,51);
puts(str);
f1.close();
}

void digitcount()     //#2
{fstream f1; int digicount=0;
f1.open("ARCHIE.txt",ios::in);
 if(!f1)
  { cout<<"\nNo file found!!Exitting!!";
   exit(-1);
  }
while(!f1.eof())
{ f1.getline(str,51) ;
  for(int i=0;str[i]!='\0';i++)
  if(isdigit(str[i]))
  digicount++;
}
cout<<"\nThe number of digits="<<digicount;
f1.close();
}

void alphabetcount()     //#3
{
int alphacount=0;
fstream f1;
f1.open("ARCHIE.txt",ios::in);
 if(!f1)
   {  cout<<"\nNo file found!!Exitting!!";
      exit(-1);
   }
while(!f1.eof())
{f1.getline(str,51);
for(int i=0;str[i]!='\0';i++)
{if(isalpha(str[i]))
 alphacount++;}
}
cout<<"\nThe number of alphabet="<<alphacount;
f1.close();
}


void wordcount()             //#4
{int worcount=0;
fstream f1;
f1.open("ARCHIE.txt",ios::in);
 if(!f1)
 { cout<<"\nNo file found!!Exitting!!";
   exit(-1);
  }
while(!f1.eof())
{f1.getline(str,51);
for(int i=0;str[i]!='\0';i++)
{if(str[i]==' ')
worcount++;
 }
}
cout<<"\nThe word count in the string is= "<<worcount;
f1.close();
}

void linecount()          //#5
{int lincount=0;fstream f1;
f1.open("ARCHIE.txt",ios::in);
if(!f1)
{ cout<<"\nNo file found!!EXITTING!!";
 exit(-1);
}
while(!f1.eof())
{f1.getline(str,51);
lincount++;
}
cout<<"\nThe line count in the string= "<<lincount;
f1.close();
}

void spacecount()        //#6
{int spaccount=0;
fstream f1;
f1.open("ARCHIE.txt",ios::in);
if(!f1)
{cout<<"\nNo file found!!Exitting!!";
exit(-1);
  }
while(!f1.eof())
{f1.getline(str,51);
for(int i=0;str[i]!='\0';i++)
{if(str[i]==' ')
{spaccount++;}
}}
cout<<"\nSpace count in the string="<<spaccount;
f1.close();
}

void vowelcount()                 //#7
{int vowcount=0; int consonantcount=0;
fstream f1;
f1.open("ARCHIE.txt",ios::in);
  if(!f1)
  { cout<<"\nNo file found!!Exitting!!";
   exit(-1);
  }
while(!f1.eof())
{ f1.getline(str,51);
for(int i=0; str[i]!='\0';i++)
{ switch(str[i])
{ case 'a':
  case 'A':
  case 'e':
  case 'E':
  case 'i':
  case 'I':
  case 'o':
  case 'O':
  case 'u':
  case 'U':vowcount++;break;
  default :consonantcount++;break;
}
}
}
cout<<"\nThe number of vowels are= "<<vowcount;
f1.close();
}

void consonantcount()                 //#7
{int consonancount=0;
fstream f1;
f1.open("ARCHIE.txt",ios::in);
  if(!f1)
  { cout<<"\nNo file found!!Exitting!!";
   exit(-1);
  }
while(!f1.eof())
{ f1.getline(str,51);
for(int i=0; str[i]!='\0';i++)
{ switch(str[i])
{ case 'a':
  case 'A':
  case 'e':
  case 'E':
  case 'i':
  case 'I':
  case 'o':
  case 'O':
  case 'u':
  case 'U':break;
  default :consonancount++;break;
}
}
}
cout<<"\nThe number of consonants are= "<<consonancount;
f1.close();
}
void uppercount()        //#8
 {int uppecount=0,lowercount=0;fstream f1;
  f1.open("ARCHIE.txt",ios::in);
  if(!f1)
  { cout<<"\nNo file found!!Exitting!!";
   exit(-1);
  }
  while(!f1.eof())
  {f1.getline(str,51);
  for(int i=0;str[i]!='\0';i++)
    if(isupper(str[i]))
    uppecount++;
    if(islower(str[i]))
    lowercount++;
  }
  cout<<"\nThe number of uppercase characters in the string are="
  <<uppecount;
  f1.close();
}

void lowercount()        //#8
 {int lowecount=0;
 fstream f1;
  f1.open("ARCHIE.txt",ios::in);
  if(!f1)
  { cout<<"\nNo file found!!Exitting!!";
   exit(-1);
  }
  while(!f1.eof())
  {f1.getline(str,51);
  for(int i=0;str[i]!='\0';i++)
    if(islower(str[i]))
    lowecount++;
  }
  cout<<"\nThe number of lowercase characters in the string are="
  <<lowecount;
  f1.close();
}

void countTHE()          //#9
{int thecount=0;
fstream f1;
f1.open("ARCHIE.txt",ios::in);
if(!f1)
{cout<<"\nNo file found!!Exitting!!";
exit(-1);}
while(!f1.eof())
{f1.getline(str,51);
 for(int i=0;str[i]!='\0';i++)
 {
 if(str[i]=='T'||str[i]=='t')
 {
 if((str[i+1]=='H'||str[i+1]=='h')&&(str[i+2]=='E')||(str[i+2]=='e'))
 {thecount++;}
 }
 }}
cout<<"\nThe number of 'The's are="<<thecount;
f1.close();}

void threecount()
{int threcount=0;
fstream f1;
 f1.open("ARCHIE.txt",ios::in);
   if(!f1)
     { cout<<"\nNo file found!!Exitting!!";
       exit(-1);}
int flag=0;
while(!f1.eof())
   {f1.getline(str,51);
      for(int i=0;str[i]!='\0';i++)
	 {if(str[i]==' ')
	   {if(str[i+4]==' '||str[i+4]=='\0')
     { for (int j=1;j<3;j++)
	{  if(str[i+j]==' ')
	  flag=1;break;}}}}
 if (flag==0)
 threcount++;}
 cout<<"\nNumber of three letter words="<<threcount;
 f1.close();}



void main()
{clrscr();
char ch='y';
int choice;
do
{clrscr();
cout<<"\n\tSelect an Operation";
cout<<"\n\t1.  Enter"
    <<"\n\t2.  Display"
    <<"\n\t3.  Digit Count"
    <<"\n\t4.  Alphabet Count"
    <<"\n\t5.  Word Count"
    <<"\n\t6.  Line Count"
    <<"\n\t7.  Space Count"
    <<"\n\t8.  Vowel Count"
    <<"\n\t9.  Consonant Count"
    <<"\n\t10. Upper Character Count"
    <<"\n\t11. Lower Character Count"
    <<"\n\t12. Occurence of 'THE', 'The' and 'the'"
    <<"\n\t13. No. of three letter words"
    <<"\n\t14. Exit";
cout<<"\nEnter your choice (1-13)\n";
cin>>choice;
switch(choice)
{ case 1:enter();break;
  case 2: display();break;
  case 3: digitcount();break;
  case 4: alphabetcount();break;
  case 5: wordcount();break;
  case 6: linecount() ;break;
  case 7: spacecount();break;
  case 8: vowelcount();break;
  case 9: consonantcount();break;
  case 10: uppercount();break;
  case 11:lowercount();break;
  case 12: countTHE();break;
  case 13: threecount();break;
  case 14:cout<<"\nExitting!!";exit(0);break;
  default  :cout<<"\nWrong choice entered!!..Please enter from 1-13\n";
	    break;
}
cout<<"\nWant to enter again(y/n)?\n";
cin>>ch;
}while((ch=='y')||(ch=='Y'));
getch();
}
