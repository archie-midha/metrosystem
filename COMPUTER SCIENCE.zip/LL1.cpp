         //Program to illustrate the concept of Linked stack
#include<iostream.h>
#include<conio.h>
#include<process.h>
void push(int stack[50],int n,int &top)
{    int item;
	if(top==n-1)
	{
	cout<<"\n overflow";
	exit(0);
	}
	else
	{
	for(int i=0;i<n;i++)
	{
     cout<<"\fn enter the element";
     cin>>item;
     top=top+1;
     stack[top]=item;
     }
   }
  }

void pop(int stack[50],int &top)
{
  int item;
  if(top==-1)
  {
    cout<<"\n underflow....";
    exit(0);
    }
    else
    {
item= stack[top];
cout<<"\n element to be deleted is "<<item;
--top;
}
}
void show( int stack[50],int &top)
{ if(top==-1)
{ cout<<"\n underflow........";
  exit(0);
}
else
{ for(int j=top;j>=0;j--)
  cout<<stack[j]<<endl;
}
}
void main()
{ clrscr();
  int stack[50];
  int size;
  int t=-1;
  int choice;
  char ch='y';
  do
  {

  cout<<"\n*** menu***";
  cout<<"\n 1.enter   ";
  cout<<"\n 2.pop     ";
  cout<<"\n 3.show    ";
  cout<<"\n enter your choice";
  cin>>choice;
  switch(choice)
  { case 1:  cout<<"\n enter the no of elements u wish to add to stack";
	       cin>>size;
		push(stack,size,t);
		break;

  case 2: pop(stack,t); break;
  case 3: show(stack,t);break;
    default :cout<<"\n wrong choice";
  }
  cout<<"do u wish to continue???";
  cin>>ch;
  }while(ch=='y');

  getch();
  }


