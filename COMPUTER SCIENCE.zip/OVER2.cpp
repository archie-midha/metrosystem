#include<iostream.h>
#include<conio.h>        //For clrscr()
#include<math.h>         //For sqrt()
#include<process.h>      //For exit()
float AREA(int a,int b,int c)       //Area of Triangle
{ float s,AR;
  s=((a+b+c)/2);
  AR=sqrt(s*(s-a)*(s-b)*(s-c));
  return AR;
}
float AREA(int a)     //Area of Square
{ return (a*a);
}
float AREA(int a,int b)     //Area of Rectangle
{ return (a*b);
}
float AREA(float radius)           //Area of Circle
{ return (3.14*radius*radius);
}
float AREA(float a,float b,float c)  //Area of Cuboid
{ return (2*((a*b)+(b*c)+(c*a)));

}
float AREA(long int a)  //Area of Cube
{ return (6*a*a);
}
void main()
{ clrscr();
  int choice,s1,s2,s3,ar1;
  float s4,s6,s7,s8,ar2;
  long int s5;
  char ch,Choice;
  do
  { cout<<"\n\t\t\t\tAREA MENU\n"
	<<"1.TRIANGLE\n"
	<<"2.SQUARE\n"
	<<"3.RECTANGLE\n"
	<<"4.CIRCLE\n"
	<<"5.CUBOID\n"
	<<"6.CUBE\n"
	<<"7.EXIT\n";
    cout<<"\nENTER YOUR CHOICE(1-7):";
    cin>>choice;
    cout<<"\n";
    switch(choice)
    { case 1: cout<<"ENTER 3 SIDES\n";
	      cin>>s1>>s2>>s3;
	      ar2=AREA(s1,s2,s3);
	      cout<<"THE AREA IS:"<<ar2<<"\n";
	      break;
      case 2: cout<<"ENTER SIDE:";
	      cin>>s1;
	      ar1=AREA(s1);
	      cout<<"THE AREA IS:"<<ar1<<"\n";
	      break;
      case 3: cout<<"ENTER LENGTH AND BREADTH:\n";
	      cin>>s1>>s2;
	      ar1=AREA(s1,s2);
	      cout<<"THE AREA IS:"<<ar1<<"\n";
	      break;
      case 4: cout<<"ENTER RADIUS OF CIRCLE:";
	      cin>>s4;
	      ar2=AREA(s4);
	      cout<<"THE AREA IS:"<<ar2<<"\n";
	      break;
      case 5: cout<<"ENTER LENGTH BREADTH AND HEIGHT:"<<"\n";
	      cin>>s6>>s7>>s8;
	      ar1=AREA(s6,s7,s8);
	      cout<<"THE AREA IS:"<<ar1<<"\n";
	      break;
      case 6: cout<<"ENTER SIDE OF CUBE:"<<"\n";
	      cin>>s5;
	      ar1=AREA(s5);
	      cout<<"THE AREA OF CUBE IS:"<<ar1<<"\n";
	      break;
      case 7: cout<<"\nSure you want to exit(y/n):";
	      cin>>ch;
	      getch();
	      if((ch=='y')||(ch=='Y'))
		exit(0);
     default: cout<<"WRONG CHOICE!!!";
  }                                     //END OF SWITCH
  cout<<"\nDo you Want to continue(y/n):";
  cin>>Choice;
  clrscr();
  }while((Choice=='y')||(Choice=='Y'));  //End of Do While
  getch();
}
