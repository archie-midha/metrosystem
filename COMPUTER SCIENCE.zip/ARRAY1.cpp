#include<iostream.h>
#include<conio.h>
void addmat()                           //function to add matrices
{ int mat1[10][10],mat2[10][10],sum[10][10],m,n,p,q,i,j;
   cout<<"\n Enter number of rows and columns of first matrix:\n ";
   cin>>m>>n;
   cout<<"\n Enter number of rows and columns of second matrix:\n";
   cin>>p>>q;
   if((m==p)&&(n==q))
   { cout<<"\n Matrices can be added.\n";
      cout<<"\n\n Enter first matrix: \n";
      for(i=0;i<m;i++)
      { for(j=0;j<n;j++)
	  cin>>mat1[i][j];
      }
      cout<<"\n Matrix 1:\n ";
      for(i=0;i<m;i++)
      { cout<<"\n";
	 for(j=0;j<n;j++)
	 cout<<" "<<mat1[i][j];
      }
      cout<<"\n\n Enter second matrix:\n ";
      for(i=0;i<p;i++)
      { for(j=0;j<q;j++)
	  cin>>mat2[i][j];
      }
      cout<<"\n Matrix 2: \n";
      for(i=0;i<p;i++)
      { cout<<"\n";
	 for(j=0;j<q;j++)
	 cout<<" "<<mat2[i][j];
      }
      for(i=0;i<m;i++)
      { for(j=0;j<n;j++)
	   sum[i][j]=mat1[i][j]+mat2[i][j];
      }
      cout<<"\n The sum of the matrices is:\n ";
      for(i=0;i<m;i++)
      { cout<<"\n ";
	 for(j=0;j<n;j++)
	  cout<<" "<<sum[i][j];
      }
   }
   else
     cout<<"\n Matrices cannot be added.\n";
}
void submat()                              //function to subtract matrices
{ int mat1[10][10],mat2[10][10],diff[10][10],m,n,p,q,i,j;
   cout<<"\n Enter number of rows and columns of first matrix:\n ";
   cin>>m>>n;
   cout<<"\n Enter number of rows and columns of second matrix:\n ";
   cin>>p>>q;
   if((m==p)&&(n==q))
   { cout<<"\n Matrices can be subtracted.\n";
      cout<<"\n\n Enter first matrix:\n" ;
      for(i=0;i<m;i++)
      { for(j=0;j<n;j++)
	  cin>>mat1[i][j];
      }
      cout<<"\n Matrix 1:\n ";
      for(i=0;i<m;i++)
      { cout<<"\n";
	 for(j=0;j<n;j++)
	 cout<<" "<<mat2[i][j];
      }
      cout<<"\n\n Enter second matrix:\n";
      for(i=0;i<p;i++)
      { for(j=0;j<q;j++)
	  cin>>mat2[i][j];
      }
      cout<<"\n Matrix 2: \n";
      for(i=0;i<p;i++)
      { cout<<"\n";
	 for(j=0;j<q;j++)
	 cout<<" "<<mat2[i][j];
      }
      for(i=0;i<m;i++)
      { for(j=0;j<n;j++)
	   diff[i][j]=mat1[i][j]-mat2[i][j];
      }
      cout<<"\n The difference of the matrices is: \n";
      for(i=0;i<m;i++)
      { cout<<"\n ";
	 for(j=0;j<n;j++)
	  cout<<" "<<diff[i][j];
      }
   }
   else
     cout<<"\n Matrices cannot be subtracted.";
}
void prodmat()                             //function to multiply matrices
{ int mat1[10][10],mat2[10][10],prod[10][10],m,n,p,q,i,j,k;
   cout<<"\n Enter number of rows and columns of first matrix: \n";
   cin>>m>>n;
   cout<<"\n Enter number of rows and columns of second matrix: \n";
   cin>>p>>q;
 if(n==p)
 { cout<<"\n Matrices can be multiplied.\n";
   cout<<"\n\n Enter first matrix: \n";
   for(i=0;i<m;i++)
   { for(j=0;j<n;j++)
	cin>>mat1[i][j];
   }
   cout<<"\n Matrix 1: ";
   for(i=0;i<m;i++)
   { cout<<"\n";
      for(j=0;j<n;j++)
      cout<<" "<<mat2[i][j];
   }
    cout<<"\n\n Enter second matrix: \n";
    for(i=0;i<p;i++)
    { for(j=0;j<q;j++)
	cin>>mat2[i][j];
    }
    cout<<"\n Matrix 2: ";
    for(i=0;i<p;i++)
    { cout<<"\n";
       for(j=0;j<q;j++)
	 cout<<" "<<mat2[i][j];
    }
    cout<<"\n Product of the matrices is: \n";
    for(i=0;i<m;i++)
    { cout<<"\n";
       for(j=0;j<n;j++)
       { prod[i][j]=0;
	  for(k=0;k<n;k++)
	    prod[i][j]+=mat1[i][k]*mat2[k][j];
	  cout<<prod[i][j]<<" ";
       }
    }
  }
  else
   cout<<"\n Matrices cannot be multiplied.\n";
}
void main()
{ clrscr();
   int choice;
   char ch;
   do
   {clrscr();
    cout<<"\n\t MATRIX MENU ";
   cout<<"\n 1. Add matrices"<<"\n 2. Subtract matrices"<<"\n 3. Multiply matrices";
   cout<<"\n Enter choice(1-3):\n ";
   cin>>choice;
      switch(choice)
      { case 1: addmat();
		     break;
	 case 2: submat();
		     break;
	 case 3: prodmat();
		     break;
	 default: cout<<"\n Wrong choice!!!";
		       break;
      }
      cout<<"\n Want to enter again?(y/n)\n ";
      cin>>ch;
      if(ch=='y'||ch=='Y')
	cout<<"\n Enter choice again(1-3): \n";
   } while(ch=='y'||ch=='Y');
   getch();
}










 
