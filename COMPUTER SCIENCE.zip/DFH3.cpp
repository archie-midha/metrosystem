#include<fstream.h>
#include<conio.h>
#include<process.h>                        //Header files
#include<stdio.h>
#include<iomanip.h>
class Applicant
{ char A_Rno[10];
  char A_Name[30];
  int A_Score;
 public:
  void Enrol()
  { cout<<"Enter your roll no.: ";
    gets(A_Rno);
    cout<<"Enter Your name: ";
    gets(A_Name);
    cout<<"Enter the score: ";
    cin>>A_Score;
    cout<<"\n";
  }
  void Status()
  { cout<<"\n# Roll No.: "<<setw(12)<<A_Rno
	<<"\n# Name: "<<setw(32)<<A_Name
	<<"\n#Score: "<<setw(3)<<A_Score<<endl;
  }
  int Returnscore()
  { return A_Score;
  }
};
void Write()                               //func 1, writing to binary file
{ ofstream fout;
  Applicant A[3];
  fout.open("APPLY.dat",ios::out|ios::binary);
  for(int i=0;i<3;i++)
  { A[i].Enrol();
    fout.write((char*)&A[i],sizeof(A[i]));
    fout<<endl;
  }
  fout.close();
}
void Read()                                //func 2, reading & disp. from it
{ ifstream fin;
  Applicant A[3];
  fin.open("APPLY.dat",ios::in|ios::binary);
  while(!fin.eof())
  { int i=0;
    fin.read((char*)&A[i],sizeof(A[i]));
    A[i].Status();i++;
  }
  fin.close();
}
void Search()                              //func 3, A_score>70
{ ifstream Fin;
  Applicant A[3];
  Fin.open("APPLY.dat",ios::in|ios::binary);
  while(!Fin.eof())
  { int i=0;
    Fin.read((char*)&A[i],sizeof(A[i]));
    if(A[i].Returnscore()>70)
    { cout<<"Marks > 70 : \n";
      A[i].Status();
    }
    i++;
  }
  Fin.close();
}
void main()
{ clrscr();
  int x;
  char q;
  Applicant A[3];
  do
  { clrscr();
    cout<<"........MENU........\n"
	<<"1.Write\n"
	<<"2.Read\n"
	<<"3.Search\n"
	<<"enter any one(1-3):\n";
    cin>>x;
    switch(x)
    { case 1:cout<<"\nWriting to the binary file\n";Write();
	     break;
      case 2:cout<<"\nReading and Displaying\n";Read();
	     break;
      case 3:cout<<"\nSearching for Score>70\n";Search();
	     break;
      default:cout<<"Wrong choice...Enter right choice..\n";
	      break;
    };
    cout<<"Do you want to continue? ";
    cin>>q;
  }while((q=='y')||(q=='Y'));
  cout<<"\nExiting...";
 getch();
}
