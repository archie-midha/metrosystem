                           //Program to illustrate the concept of Stack
#include<iostream.h>
#include<conio.h>
#include<process.h>
class stack
{ int stack[50];
  int top;
  int size;
  public:
  stack()
  { top=-1;
  }
  void push();
  void pop();
  void show();
  };

void stack::push()
{       cout<<"\n enter size";
cin>>size;
	int item;
	if(top==size-1)
	{
	cout<<"\n overflow";
	exit(0);
	}
	else
	{
	for(int i=0;i<size;i++)
	{
     cout<<"\n enter the element";
     cin>>item;
     top=top+1;
     stack[top]=item;
     }
   }
  }

void stack::pop()
{
  int item;
  if(top==-1)
  {
    cout<<"\n underflow....";
    exit(0);
    }
    else
    {
item= stack[top];
cout<<"\n element to be deleted is "<<item;
--top;
}
}
void stack::show()
{ if(top==-1)
{ cout<<"\n underflow........";
  exit(0);
}
else
{ for(int j=top;j>=0;j--)
  cout<<stack[j]<<endl;
}
}
void main()
{ clrscr();
  stack s1;


  int choice;
  char ch='y';
  do
  {

  cout<<"\n*** menu***";
  cout<<"\n 1.push   ";
  cout<<"\n 2.pop     ";
  cout<<"\n 3.show    ";
  cout<<"\n enter your choice";
  cin>>choice;
  switch(choice)
  { case 1:s1.push();break;

  case 2: s1.pop(); break;
  case 3: s1.show();break;
    default :cout<<"\n wrong choice";
  }
  cout<<"do u wish to continue???";
  cin>>ch;
  }while(ch=='y');

  getch();
  }

