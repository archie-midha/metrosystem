/*Program to illustrate various operations on BINARY FILES using class �item*/

#include<fstream.h>
#include<conio.h>
#include<stdio.h>
#include<string.h>                //for string functions
#include<process.h>

class item                        //class declared
{int icode,qty;
 char name[20];
 float price;
 public:
 void enter()
 {
  cout<<" \n Enter Detils .. \n Item Code : ";
   cin>>icode;
  cout<<" \n Enter Item Name : ";
   gets(name);
  cout<<" \n Enter Quantity : ";
   cin>>qty;
  cout<<" \n Enter Price : ";
   cin>>price;
  cout<<" \n Details Saved ... ";
 }
 void show()
 {
  cout<<"\n\n Item Code : "<<icode<<"\n Item Name : "<<name<<" \n Quantity : "<<qty<<" \n Price : "<<price;
 }
 void appendfile();
 void readfile();
 void createfile();
 void search();
 void deletefile();
 void modify();
 void insert();
 void copy();
}x1;

void item::readfile()                 //1
{
  cout<<"\nREAD...";
  cout<<"\n Saved Records ... ";
  ifstream f1("ARCHIE.dat",ios::binary,ios::in);
   while (f1.read((char*)&x1,sizeof(x1)))
  {
   x1.show();
   getch();
  }
 f1.close();
}

void item::appendfile()               //2
{
  cout<<"\nAPPEND";
  ofstream f1("ARCHIE.dat",ios::binary|ios::out|ios::app);
  if(f1)
  { x1.enter();
    f1.write((char*)&x1,sizeof(x1));
  }
  f1.close();
}

void item::createfile()               //3
{cout<<"\nCREATE";
 char ch;
 cout<<"\nIMPORTANT MESSAGE:NO DATA WILL BE SAVED IF THE FILE ALREADY EXISTS!! \n\n (Type `e' to exit `c' to continue) :\n ";
  cin>>ch;
 if(ch=='c')
 {ofstream f1("ARCHIE.dat",ios::binary);
  x1.enter();
  f1.write((char*)&x1,sizeof(x1));
  cout<<"\nWriting in file\n";
  f1.close();
 }
}

void item::search()                   //4
{
 int n,f=0,ch,quanti;
 float p;
 char itemname[20];
 cout<<"\n \t\t\t\t Search Menu .. \n\n 1.) By Code \n\n 2.) By Name \n\n 3.) By Quantity \n\n 4.) By Price \n\n\n";
 cout<<"\n Enter the desired from above options::\n ";
 cin>>ch;
 ifstream f1("ARCHIE.dat",ios::binary,ios::in);
 switch(ch)
 {
  case 1  :  cout<<"\n Enter Item Code : ";
	      cin>>n;
	     while(f1.read((char*)&x1,sizeof(x1)))
	     {if(n==icode)
	      {x1.show(); f=1;}
	     }
	    break;
  case 2  : cout<<"\n Enter Name to be searched for : ";
	     gets(itemname);
	    while(f1.read((char*)&x1,sizeof(x1)))
	     {if(strcmp(itemname,name)==0)
	      {x1.show(); f=1;}
	     }
	    break;
  case 3  : cout<<"\n Enter Quantity to be searched for : ";
	     cin>>quanti;
	    while(f1.read((char*)&x1,sizeof(x1)))
	     {if(quanti==qty)
	      {x1.show(); f=1;}
	     }
	    break;
  case 4  : cout<<"\n Enter Price to search for : ";
	     cin>>p;
	    while(f1.read((char*)&x1,sizeof(x1)))
	     {if(p==price)
	      {x1.show(); f=1;}
	     }
	    break;
  default : cout<<"\n Wrong Choice Entered!Please enter again! ";
	    break;}
 if(f==0)
 {cout<<"\nNo records found";}
 f1.close();
}

void item::deletefile()               //5
{ int n, f=0;
 cout<<"\n Enter Item Code for which record is to be deleted : ";
  cin>>n;
 ifstream f1("ARCHIE.dat",ios::binary|ios::in);
 ofstream f2("temp.dat",ios::binary|ios::out);
  while(f1.read((char*)&x1,sizeof(x1)))
  {if(icode!=n)
     {f2.write((char*)&x1,sizeof(x1));
     f=1;}
   else
    f=0;
  }
 if(f==0)
 cout<<"\nDeleted ";
 else
 cout<<"\nNO Record Deleted!";
 f1.close();
 f2.close();
 remove("ARCHIE.dat");
 rename("temp.dat","ARCHIE.dat");
}

void item::modify()                //6
{
 int n,f=0,code,newqty;
 float p;
 char nname[20];
 cout<<"\n Enter Item code for item to be modified : ";
  cin>>n;
 ifstream f1("ARCHIE.dat",ios::binary|ios::in);
 ofstream f2("temp.dat",ios::binary|ios::out);
 while(f1.read((char*)&x1,sizeof(x1)))
 {if(icode==n)
  {f=1;
   cout<<"\n Enter New Item Code(enter -1 to retain old) : ";
    cin>>code;
   cout<<"\n New Item Name(enter * to retain old)  : ";
    gets(nname);
   cout<<"\n New Item Qty.(enter -1 to retain old) : ";
    cin>>newqty;
   cout<<"\n New Item Price(enter -1 to retain old) : ";
    cin>>p;
   if (code!=-1)
   icode=code;
   if (strcmp(nname,"*")!=0)
   strcpy(name,nname);
   if(newqty!=-1)
   qty=newqty;
   if(p!=-1)
   price=p;
   f2.write((char*)&x1,sizeof(x1));
  }
  else
   f2.write((char*)&x1,sizeof(x1));
 }
 if(f==0)
  cout<<"\n No Record Found ... ";
 f1.close();
 f2.close();
 remove("ARCHIE.dat");
 rename("temp.dat","ARCHIE.dat");
}

void item::insert()               //7
{
 int n,f=0;
 item x2;
 cout<<"\n Enter Item Code : ";
 cin>>n;
 ifstream f1("ARCHIE.dat",ios::binary|ios::in);
 ofstream f2("temp.dat",ios::binary|ios::out);
  while(f1.read((char*)&x1,sizeof(x1)))
  {if((n>icode)&&(f==0))
   { x2.enter();
     f2.write((char*)&x2,sizeof(x2));
     f=1;
   }
   f2.write((char*)&x1,sizeof(x1));
  }
  f1.close();
  f2.close();
  remove("ARCHIE.dat");
  rename("temp.dat","ARCHIE.dat");
  }

void item::copy()            //8
{
 int n,f=0;
 cout<<"\n Enter Item Code : ";
 cin>>n;
 ifstream f1("ARCHIE.dat",ios::binary|ios::in);
 ofstream f2("temp.dat",ios::binary|ios::out);
  while(f1.read((char*)&x1,sizeof(x1)))
  {if(n==icode)
   {
    f2.write((char*)&x1,sizeof(x1));
    f=1;
    cout<<"\n Matching Record copied to `temp.dat'";
   }
  }
  f1.close();
  f2.close();
  if(f==0)
   cout<<" \n Record not found!! ";
}


void main()        //main starts
{
 int ch;
 do
 {
  clrscr();
  cout<<"\n\t\t\tCHOOSE THE DESIRED OPERATIONS... \n 1) Create \n\n 2) Append \n\n 3) Show Data \n\n 4) Delete \n\n 5) Search \n\n 6) Modify \n\n 7) Insert \n\n 8) Copy \n\n 9) Exit \n\n Enter your choice : ";
  cin>>ch;
  clrscr();
  switch(ch)
  {
    case 1  : x1.createfile();
	      break;
    case 2  : x1.appendfile();
	      break;
    case 3  : x1.readfile();
	      break;
    case 4  : x1.deletefile();
	      break;
    case 5  : x1.search();
	      break;
    case 6  : x1.modify();
	      break;
    case 7  : x1.insert();
	      break;
    case 8  : x1.copy();
	      break;
    case 9  : cout<<" \nEXITTING!! ";
	      break;
    default   : cout<<" \n Wrong Choice Entered, Pls. enter again!! ";
	      break;
   }
 getch();
 }while(ch!=9);
}             //end of main




 

 


 
 
 
 

 
 
 
 
 
       

 
 
 
 
