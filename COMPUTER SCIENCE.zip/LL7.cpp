                             //Program to illustrate the concept of Stacks
#include<iostream.h>
#include<conio.h>
#include<process.h>
struct item
{ char itemname[20];
  int itemno;
 item *next;
  };
  item *temp;
  class stack
 { 	item *top;
	public:
	void add();
	void del();
	void show();
	stack()
	{top=NULL;
	}
 };
void main()
{ 	clrscr();
	int choice;
	char ch='y';
	stack s1;


  do{
	cout<<"\n*** menu***";
	cout<<"\n 1.push   ";
	cout<<"\n 2.pop     ";
	cout<<"\n 3.show    ";
	cout<<"\n enter your choice";
	cin>>choice;
  switch(choice)
  { 	case 1:s1.add();break;

	case 2:s1.del(); break;
	case 3: s1.show();break;
	default :cout<<"\n wrong choice";
  }
	cout<<"do u wish to continue???";
	cin>>ch;
  }while(ch=='y');

	getch();
  }
 void stack::add()
 {	temp=new item;
	cout<<"\n enter value";
	cout<<"*********pl enter carefully******";



	cin>>temp->itemname>>temp->itemno;
	temp->next=NULL;
	if(top==NULL)
	top=temp;
 else
 {	temp->next=top;
	top=temp;
 }
 }
void stack::del()
 {
 if(top==NULL)
 {
   cout<<"Underflow";
   exit(0);
 }
 else
 {
   temp=top;
   cout<<"values to be deleted are:";
   cout<<temp->itemname<<temp->itemno;
   top=temp->next;
   temp->next=NULL;
   delete temp;

 }
 }
 void stack::show()
 {
   if(top==NULL)
   {
     cout<<"Underflow";
     exit(0);
     }
     else
     {
     temp=top;
     while(temp!=NULL)
     {
       cout<<temp->itemname<<temp->itemno;
       cout<<".....";
       temp=temp->next;
       }
     }
   }

