               //Program to illustrate the concept of Linked Queue
#include<iostream.h>
#include<conio.h>
#include<process.h>
struct item
{ int itemno;
  char itemname[20];
  item *ptr;
  }; item *temp;
class queue
{ item *f,*r;
  public:
  void add();
  void del();
  void show();
  queue()
  { f=r=NULL;
  }
};
void queue::add()
{ temp=new item;
cout<<"\n enter data";
cin>>temp->itemno>>temp->itemname;
temp->ptr=NULL;
if(r==NULL)
{ f=r=temp;
}
else
{ r->ptr=temp;
  r=temp;
}
}

void queue::del()
 {
 if(f==NULL)
 {
   cout<<"Underflow";
   exit(0);
 }
 else
 {
   temp=f;
   cout<<"values to be deleted are:";
   cout<<temp->itemname<<temp->itemno;
   f=temp->ptr;
   temp->ptr=NULL;
   delete temp;

 }
 }
 void queue ::show()
 { if(f==NULL)
 {cout<<"\n underflow";
  exit(0);
 }
 else
 { temp=f;
   while(temp!=NULL)
   { cout<<" values are";
     cout<<temp->itemno<<temp->itemname;
     temp=temp->ptr;
   }
  }
  }
  void main()
{ 	clrscr();
	int choice;
	char ch='y';
	queue q1;


  do{
	cout<<"\n*** menu***";
	cout<<"\n 1.push   ";
	cout<<"\n 2.pop     ";
	cout<<"\n 3.show    ";
	cout<<"\n enter your choice";
	cin>>choice;
  switch(choice)
  { 	case 1:q1.add();break;

	case 2:q1.del(); break;
	case 3: q1.show();break;
	default :cout<<"\n wrong choice";
  }
	cout<<"do u wish to continue???";
	cin>>ch;
  }while(ch=='y');

	getch();
  }
