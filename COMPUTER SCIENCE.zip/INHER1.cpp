#include<iostream.h>
#include<conio.h>                 //for clrscr()
#include<stdio.h>                  //for gets() and puts()
class Employee               //Base class
{ public :
  int Number,House;
  char City[20],State[20],Name[20],Department[20];
  void Input()
  { cout<<"\nEnter the Employee's Name:";
    gets(Name);
    cout<<"\nEnter Employee Number:";
    cin>>Number;
    cout<<"\nEnter Address:";
    cout<<"\nEnter House:";
    cin>>House;
    cout<<"\nEnter City:";
    gets(City);
    cout<<"\nEnter State:";
    gets(State);
    cout<<"\nEnter Department of Employee:";
    gets(Department);
  }
  void Output()
  { cout<<"\nEmployee's Information:"
	<<"\n"<<"Name:"<<Name<<"\n"<<"Employee Number:"<<Number
	<<"\n"<<"Address:"<<House<<","<<City<<","<<State
	<<"\n"<<"Department:"<<Department;
  }
};
class Manager:public Employee              //Derived class
{ char Name[20];
  int i,j;
  public : void Getdata()
	   { cout<<"\nEnter the Managers Name:";
	     gets(Name);
	     cout<<"\nEnter the total number of"
		 <<" Employees working under him:";
	     cin>>i;
	   }
	   void Info();
}M1;
void Manager::Info()
{ Getdata();
  for(j=0;j<i;j++)
    Input();
  cout<<"\nEmployee's are:";
  for(j=0;j<i;j++)
  { cout<<"\nEmployee number:"<<i;
    Output();
  }
}
void main()
{ clrscr();
   M1.Info();
   getch();  
}
