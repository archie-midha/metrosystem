//Program to illustrate the concept of Linked Queue
#include<iostream.h>
#include<conio.h>
#include<process.h>
class Q
{ int Q1[50];
  int f,r;
  int size;
  public:
  Q()
  { f=r=-1;
  }
  void push();
  void pop();
  void show();
  };

void Q::push()
{ int item;       int size;
cout<<"\n enter size";
cin>>size;
for(int i=0;i<size;i++)
{

	cout<<"enter ele";
	cin>>item;
	if(r<size)
	{
	Q1[++r]=item;
	}
	else
	{
	cout<<"overflow";
	}
       }
	}
void Q::pop()
{
  int item;
  if(f!=r)
  {
     item=Q1[++f];
     cout<<"deleted" <<item;
     }
     else
     {
    cout<<"\n underflow....";
    }
}
void Q::show()
{ int i;
if(f<r)
{ for(i=f+1;i<=r;i++)
  cout<<Q1[i]<<endl;
}
}
void main()
{ clrscr();
  Q s1;


  int choice;
  char ch='y';
  do
  {

  cout<<"\n*** menu***";
  cout<<"\n 1.push   ";
  cout<<"\n 2.pop     ";
  cout<<"\n 3.show    ";
  cout<<"\n enter your choice";
  cin>>choice;
  switch(choice)
  { case 1:s1.push();break;

  case 2: s1.pop(); break;
  case 3: s1.show();break;
    default :cout<<"\n wrong choice";
  }
  cout<<"do u wish to continue???";
  cin>>ch;
  }while(ch=='y');

  getch();
  }

