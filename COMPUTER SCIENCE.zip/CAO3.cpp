#include<iostream.h>
#include<conio.h>
#include<stdio.h>
#include<process.h>
class string
{ char str1[80];
  char str2[80];
  public:
  void read()
  { cout<<"\n Enter a string: ";
    gets(str1);
  }
  void display();
  void reverse();
  void copy();
  void concat();
};
  void string::display()
  { cout<<"\n Enter a string: ";
    gets(str1);
    cout<<"\n Now displaying the string: ";
    puts(str1);
  }
  void string::reverse()
  { cout<<"\n Enter a string: ";
    gets(str1);
    cout<<"\n Now displaying the string: ";
    puts(str1);
    int length=0;
    for(int i=0;str1[i]!=0;i++)
    length++;
    i=0;
    int temp,j;
    j=length-1;
    while(i<j)
    { temp=str1[i];
      str1[i]=str1[j];
      str1[j]=temp;
      i++;
      j--;
    }
    cout<<"\n The reversed string is: ";
    puts(str1);
  }
  void string::copy()
  { char str[80];
    cout<<"\n Enter a string: ";
    gets(str1);
    cout<<"\n Now displaying the string: ";
    puts(str1);
    cout<<"\n Copying the string to an empty string.";
    int i=0;
    while(str1[i]!='\0')
    { str[i]=str1[i];
      i++ ;
    }
    str[i]='\0';
    cout<<"\n The copied string is: ";
    puts(str);
  }
  void string::concat()
  { cout<<"\n Enter a string: ";
    gets(str1);
    cout<<"\n Enter another string: ";
    gets(str2);
    cout<<"\n String 1: ";
    puts(str1);
    cout<<"\n String 2: ";
    puts(str2);
    for(int i=0;str1[i]!='\0';++i);
    for(int j=0;str2[j]!='\0';++j,++i)
    str1[i]=str2[j];
    str1[i]='\0';
    cout<<"\n After concatenation: ";
    puts(str1);
   }
void main()
{ clrscr();
  string s1;
  int choice;
  char ch;
  do{
  cout<<"\n Area menu: ";
  cout<<"\n 1.To read a string.";
  cout<<"\n 2.To display a string.";
  cout<<"\n 3.To reverse a string.";
  cout<<"\n 4.To copy a string to an empty string.";
  cout<<"\n 5.To concatenate two strings.";
  cout<<"\n 6.Exit.";
  cout<<"\n Enter choice: ";
  cin>>choice;
  switch(choice)
  { case 1 : s1.read();
	     break;
    case 2 : s1.display();
	     break;
    case 3 : s1.reverse();
	     break;
    case 4 : s1.copy();
	     break;
    case 5 : s1.concat();
	     break;
    case 6 : cout<<"\n You are exiting.";
	     exit(0);
	     break;
    default: cout<<"\n Wrong choice entered.";
	     break;
  }
  cout<<"\n Do you want to continue?(y/n)";
  cin>>ch;
 }while((ch=='y')||(ch=='Y'));
 if((ch=='n')||(ch=='N'))
  cout<<"\n You are exiting."<<"\n Thankyou for using this program.";
  getch();
}



