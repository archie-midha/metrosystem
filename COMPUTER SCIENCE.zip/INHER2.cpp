#include<iostream.h>
#include<conio.h>        //for clrscr()
#include<string.h>       //for strcpy()
#include<stdio.h>        //for gets() and puts()
class Person                 //Base class
{ public :
  char Name[20];
  long Phone;
  void Set()
  { strcpy(Name,"Null");
    Phone=9971403485;
  }
  void Get()
  { cout<<"\nEnter Name:";
    gets(Name);
    cout<<"\nEnter Phone:";
    cin>>Phone;
  }
  void Display()
  { cout<<"\nName:"<<Name;
    cout<<"\nPhone:"<<Phone;
  }
  Person()                    //default constructor
  { strcpy(Name,"Ayush");
    Phone=9971403485;
  }
  Person(char N[20],long P)   //copy constructor
  { N=Name;
    P=Phone;
  }
  void Getname()
  { cout<<"\nEnter Name:";
    gets(Name);
  }
  ~Person()                        //destructor
   { cout<<"\nObject destroyed";
   }
};
class Spouse:public Person     //derived class
{ public:
  char Sname[20];
  void Getname()
  { Get();
    cout<<"\nEnter Spouse Name:";
    gets(Sname);
  }
  void Display()
  { cout<<"\nName:"<<Name;
    cout<<"\nPhone:"<<Phone;
    cout<<"\nSpouse Name:"<<Sname;
  }
  Spouse()                 //default constructor
  { strcpy(Sname,"Null");
  }
  Spouse(char S[20])       //copy constructor
  { S=Sname;
  }
};
void main()
{ clrscr();
  Spouse S1;
  S1.Getname();
  S1.Display();
  cout<<"\n";
  Person();
  getch();
}











