//To create a file and do different operations on it using data file handling
#include<iostream.h>
#include<conio.h>
#include<fstream.h>
#include<string.h>
#include<stdio.h>
#include<process.h>
#include<ctype.h>
 void create();                                                                                                             //prototyping
 void display();
 void Alphabetcount();
 void Wordcount();
 void spacecount();
 void vowelcount();
 void main()
{
  clrscr();
  int choice=0;
  char ch;
 do
  {
   clrscr();
   cout<<"*******MENU*******"<<endl;                                                                        //menu
   cout<<"1)Create"<<endl;
   cout<<"2)Display"<<endl;
   cout<<"3)Alphabet count"<<endl;
   cout<<"4)Word count"<<endl;
   cout<<"5)space count"<<endl;
   cout<<"6)Vowel count"<<endl;
   cout<<"7)Exit"<<endl;
   cout<<"Enter your choice:";
   cin>>choice;
   switch(choice)
  {case 1:create();break;
   case 2:display();break;
   case 3:Alphabetcount();break;
   case 4:Wordcount();break;
   case 5:spacecount();break;
   case 6:vowelcount();break;
   case 7:cout<<"Exiting!!!!";exit(0);break;
   default:cout<<"Wrong choice!!!!"<<endl;break;
  }
 cout<<"\ndo you want to continue???(Y/N):";
 cin>>ch;
 }while(ch=='Y'||ch=='y');
 cout<<"Exiting!!!!";
 getch();
}
void create()                                                                                                 //function declaration
{char text[100];
  ofstream fout;
  fout.open("abc.txt",ios::out);
  if(!fout)
  { cout<<"\n File does not exist";
    exit(-1);
  }
  cout<<"Enter a string:"<<endl;
  gets(text);
  fout.write(text,100);
  fout.close();
}
void display()
{
 char text1[100];
 ifstream fin;
 fin.open("abc.txt",ios::in);
 if(!fin)
 { cout<<"File not created"<<endl;
   exit(-1);
 }
cout<<"Displaying data"<<endl;
fin.read(text1,100);
cout<<text1;
fin.close();
}

void  Alphabetcount()
{ int a=0;
  char text3[100];
  ifstream fin;
  fin.open("abc.txt",ios::in);
  if(!fin)
 { cout<<"File not created"<<endl;
   exit(0);
 }
while(!fin.eof())
{ fin.getline(text3,100);
  for(int i=0;text3[i]!='\0';i++)
   { if(isalpha(text3[i]))
     a++; }
   }
cout<<"Number of alphabets in the text="<<a<<endl;
fin.close();
}
void Wordcount()
{ int word=0;
  char text4[100];
  ifstream fin;
  fin.open("abc.txt",ios::in);
  if(!fin)
 { cout<<"File not created"<<endl;
   exit(0);
 }
while(!fin.eof())
{ fin.getline(text4,100);
  for(int i=0;text4[i]!='\0';i++)
  { if(text4[i]==' ')
    word++;
  }
}
cout<<"Number of words in the text="<<word+1<<endl;
fin.close();
}

void spacecount()
{ int space=0;
  char text6[100];
  ifstream fin;
  fin.open("abc.txt",ios::in);
  if(!fin)
  { cout<<"File not created"<<endl;
    exit(0);
  }
while(!fin.eof())
{ fin.getline(text6,100);
  for(int i=0;text6[i]!='\0';i++)
  { if(text6[i]==' ')
    space++;
  }
}
cout<<"Number of spaces in the text="<<space<<endl;
fin.close();
}
void vowelcount()
{ int vowel=0;
  char text7[100];
  ifstream fin;
  int i=0;
  fin.open("abc.txt",ios::in);
  if(!fin)
  { cout<<"File not created"<<endl;
    exit(0);
  }
while(!fin.eof())
{ fin.getline(text7,100);
  for(i=0;text7[i]!='\0';i++)
  { if(text7[i]=='A' || text7[i]=='a' || text7[i]=='E' || text7[i]=='e'||text7[i]=='I'||text7[i]=='i'||text7[i]=='O'||text7[i]=='o'||text7[i]=='U'||text7[i]=='u')
    vowel++; }
  }
cout<<"Number of vowels in the text="<<vowel<<endl;
fin.close();
}












   
 
 
 

